//
// Created by kuki on 5/28/25.
//

#include <cstdlib>
#include "mixerconfig.h"

void configure_audio_mixer()
{
    system("amixer -c 1 set 'Left HP Mixer Left DAC2',0 unmute");
    system("amixer -c 1 set 'Left HP Mixer Left DAC1',0 unmute");
    system("amixer -c 1 set 'Left ADC Mixer INB1',0 unmute");
    system("amixer -c 1 set 'Left ADC Mixer INB2',0 unmute");
    system("amixer -c 1 set 'INB',0 57%");
    system("amixer -c 1 set 'Headphone',0 60%");

    system("amixer -c 0 set 'Left HP Mixer Left DAC2',0 unmute");
    system("amixer -c 0 set 'Left HP Mixer Left DAC1',0 unmute");
    system("amixer -c 0 set 'Left ADC Mixer INB1',0 unmute");
    system("amixer -c 0 set 'Left ADC Mixer INB2',0 unmute");
    system("amixer -c 0 set 'INB',0 57%");
    system("amixer -c 0 set 'Speaker',0 40%");
}
