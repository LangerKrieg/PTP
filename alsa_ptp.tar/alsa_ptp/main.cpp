#include <iostream>
#include <csignal>

#include "Device.h"
#include "Buffer.h"
#include "udpstreamer.h"
#include "mixerconfig.h"

volatile bool keep_running = true;

void signal_handler(int sig)
{
    keep_running = false;
}

int main(int argc, char *argv[])
{
    signal(SIGINT, signal_handler);

    if (argc < 3) {
        std::cerr << "Usage: Local Ip | Listening Port | Destination Port | Destination Ip";
    }

    configure_audio_mixer();

    std::string local_ip(argv[1]);
    long listening_port = strtol(argv[2], NULL, 10);
    std::string destination_ip(argv[4]);
    long destination_port = strtol(argv[3], NULL, 10);

    try {
        Device captureDevice("hw:1,0", SND_PCM_STREAM_CAPTURE,
            SND_PCM_FORMAT_S16_LE, 8000, 1);
        Device playbackDevice("hw:1,0", SND_PCM_STREAM_PLAYBACK,
            SND_PCM_FORMAT_S16_LE, 8000, 1);

        UdpStreamer streamer(local_ip, listening_port, destination_ip,
            destination_port);
        Buffer buffer(captureDevice, playbackDevice, streamer);

        while (keep_running) {
            if (buffer.ReadFromDevice() > 0) {
                buffer.SendToUDP();
            }
            if(buffer.ReceiveFromUDP() > 0) {
                buffer.WriteToDevice();
            }
        }
    }
    catch(const std::exception &e) {
        std::cerr << "Fatal error: " << e.what() << "\n";
        return 1;
    }

    return 0;
}
