#include "Buffer.h"

Buffer::Buffer(const Device& capture_device, const Device& playback_device,
    UdpStreamer& udp)
    : captureDevice_(capture_device),playbackDevice_(playback_device),
      gateway_(udp), writeInBufPosition_(0), writeFromUdpPosition_(0),
      writeInAlsaPosition_(0)
{
    if (capture_device.GetFormat() != playback_device.GetFormat() ||
        capture_device.GetChannels() != playback_device.GetChannels() ||
        capture_device.GetRate() != playback_device.GetRate() ||
        capture_device.GetPeriodSize() != playback_device.GetPeriodSize())
    {
        throw std::runtime_error(std::string("Incompatible devices parameters"));
    }

    frameSize_ = format_to_bytes(captureDevice_.GetFormat()) * captureDevice_.GetChannels();
    framesPerPeriod_ = captureDevice_.GetPeriodSize();
    bufferSize_ = frameSize_ * framesPerPeriod_ * 8;

    buffer_.resize(bufferSize_);

    snd_pcm_prepare(captureDevice_.GetHandle());
    snd_pcm_prepare(playbackDevice_.GetHandle());
    pthread_mutex_init(&bufferMutex_, NULL);
}


Buffer::~Buffer()
{
    pthread_mutex_destroy(&bufferMutex_);
}


// Alsa format to bytes
int Buffer::format_to_bytes(snd_pcm_format_t format) {
    switch (format) {
        case SND_PCM_FORMAT_S8: return 1;
        case SND_PCM_FORMAT_S16_LE: return 2;
        case SND_PCM_FORMAT_S24_LE: return 3;
        default:
            throw std::runtime_error(std::string("Unsupported format"));
    }
}

void Buffer::ErrorHandler(int err, const Device &device) {
    switch (err) {
        case -EPIPE:
        case -ESTRPIPE:
            RecoverBuffer(device, err);
            break;

        case -EAGAIN:
            snd_pcm_wait(device.GetHandle(), 1000000);
            break;

        default:
            throw std::runtime_error(std::string("An fatal error occurred. ")
                + strerror(err));
    }
}


void Buffer::RecoverBuffer(const Device &device, int error)
{
    int return_code = 0;
    if ((return_code = snd_pcm_recover(device.GetHandle(), error, 1)) < 0)
        throw std::runtime_error(std::string("Failed to recover buffer. ")
            + snd_strerror(return_code));
}


snd_pcm_sframes_t Buffer::ReadFromDevice() {
    pthread_mutex_lock(&bufferMutex_);

    // Calculate free space
    size_t free_bytes = (writeInBufPosition_ >= writeFromUdpPosition_)
        ? bufferSize_ - (writeInBufPosition_ - writeFromUdpPosition_)
        : writeFromUdpPosition_ - writeInBufPosition_;

    size_t free_frames = snd_pcm_bytes_to_frames(captureDevice_.GetHandle(), free_bytes);

    if (free_frames >= framesPerPeriod_) {
        for (int i = 0; i < 3; ++i) { // 3 attempts
            char* dest = buffer_.data() + writeInBufPosition_;

            snd_pcm_sframes_t read_frames = snd_pcm_readi(captureDevice_.GetHandle(),
                dest, framesPerPeriod_);

            if (read_frames >= 0) {
                writeInBufPosition_ = (writeInBufPosition_ +
                    snd_pcm_frames_to_bytes(captureDevice_.GetHandle(), read_frames)) % bufferSize_;

                pthread_mutex_unlock(&bufferMutex_);
                return read_frames;
            }

            ErrorHandler(read_frames, captureDevice_);
            usleep(100000);
        }
    }

    pthread_mutex_unlock(&bufferMutex_);
    return 0;
}


snd_pcm_sframes_t Buffer::SendToUDP() {
    pthread_mutex_lock(&bufferMutex_);

    size_t bytes_to_send = snd_pcm_frames_to_bytes(captureDevice_.GetHandle(), framesPerPeriod_);
    std::vector<char> temp(bytes_to_send);

    // Copying data from ring buffer to linear
    size_t start = (writeInBufPosition_ + bufferSize_ - bytes_to_send) % bufferSize_;

    if (start + bytes_to_send <= bufferSize_) {
        std::memcpy(&temp[0], &buffer_[start], bytes_to_send);
    }
    else {
        size_t first_part = bufferSize_ - start;
        std::memcpy(&temp[0], &buffer_[start], first_part);
        std::memcpy(&temp[0] + first_part, &buffer_[0], bytes_to_send - first_part);
    }

    try {
        gateway_.Send(&temp[0], bytes_to_send);

        pthread_mutex_unlock(&bufferMutex_);
        return snd_pcm_bytes_to_frames(captureDevice_.GetHandle(), bytes_to_send);
    }
    catch (...) {
        pthread_mutex_unlock(&bufferMutex_);
        return 0;
    }
}

snd_pcm_sframes_t Buffer::ReceiveFromUDP() {
    pthread_mutex_lock(&bufferMutex_);

    size_t bytes = snd_pcm_frames_to_bytes(playbackDevice_.GetHandle(), framesPerPeriod_);
    std::vector<char> temp(bytes);

    size_t received = gateway_.Receive(temp.data(), bytes);
    if (received == 0) {
        std::memset(&temp[0], 0, bytes); // Silence while no data
    }

    // Receive to ring buffer
    if (writeFromUdpPosition_ + bytes <= bufferSize_) {
        std::memcpy(&buffer_[writeFromUdpPosition_], &temp[0], bytes);
    }
    else {
        size_t first_part = bufferSize_ - writeFromUdpPosition_;
        std::memcpy(&buffer_[writeFromUdpPosition_], &temp[0], first_part);
        std::memcpy(&buffer_[0], &temp[0] + first_part, bytes - first_part);
    }

    writeFromUdpPosition_ = (writeFromUdpPosition_ + bytes) % bufferSize_;

    pthread_mutex_unlock(&bufferMutex_);
    return snd_pcm_bytes_to_frames(playbackDevice_.GetHandle(), bytes);
}


snd_pcm_sframes_t Buffer::WriteToDevice() {
    pthread_mutex_lock(&bufferMutex_);

    // Calculate available frames
    size_t available_bytes = (writeFromUdpPosition_ >= writeInAlsaPosition_)
        ? writeFromUdpPosition_ - writeInAlsaPosition_
        : bufferSize_ - (writeInAlsaPosition_ - writeFromUdpPosition_);

    size_t available_frames = snd_pcm_bytes_to_frames(playbackDevice_.GetHandle(), available_bytes);

    if (available_frames >= framesPerPeriod_) {
        for (int i = 0; i < 3; ++i) { // 3 attempts
            char* src = &buffer_[writeInAlsaPosition_];
            snd_pcm_sframes_t written = snd_pcm_writei(playbackDevice_.GetHandle(), src,
                framesPerPeriod_);

            if (written >= 0) {
                writeInAlsaPosition_ = (writeInAlsaPosition_ +
                    snd_pcm_frames_to_bytes(playbackDevice_.GetHandle(), written)) % bufferSize_;

                pthread_mutex_unlock(&bufferMutex_);
                return written;
            }

            ErrorHandler(written, playbackDevice_);
            usleep(100000);
        }
    }

    pthread_mutex_unlock(&bufferMutex_);
    return 0;
}
