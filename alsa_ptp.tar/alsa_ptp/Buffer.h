#ifndef BUFFER_H
#define BUFFER_H

#include "Device.h"
#include "udpstreamer.h"

#include <alsa/asoundlib.h>
#include <vector>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <unistd.h>

class UdpStreamer;

class Buffer {
public:
    Buffer(const Device& capture_device, const Device& playback_device,
        UdpStreamer& udp);
    ~Buffer();

    snd_pcm_sframes_t ReadFromDevice();
    snd_pcm_sframes_t SendToUDP();
    snd_pcm_sframes_t ReceiveFromUDP();
    snd_pcm_sframes_t WriteToDevice();

private:
    const Device& captureDevice_;
    const Device& playbackDevice_;
    UdpStreamer& gateway_;

    // Ring buffer
    std::vector<char> buffer_;
    size_t bufferSize_;
    size_t frameSize_;
    size_t framesPerPeriod_;

    // Buffer positions
    size_t writeInBufPosition_;     // receive from micro
    size_t writeFromUdpPosition_;   // receive from udp
    size_t writeInAlsaPosition_;    // play

    pthread_mutex_t bufferMutex_;

    int format_to_bytes(snd_pcm_format_t format);
    void ErrorHandler(int err, const Device &device);
    void RecoverBuffer(const Device &device, int error);
};

#endif // BUFFER_H
