#ifndef MIXERCONFIG_H
#define MIXERCONFIG_H

void configure_audio_mixer();

#endif
