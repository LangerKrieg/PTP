#include <iostream>
#include <csignal>

#include "Device.h"
#include "Buffer.h"
#include "udpstreamer.h"
#include "mixerconfig.h"

typedef std::pair<std::string, std::string> KeyValuePair;
typedef std::vector<KeyValuePair> KeyValueStorage;

volatile bool keep_running = true;

void signal_handler(int sig)
{
    keep_running = false;
}

void setValue(KeyValueStorage &storage, const std::string &key, const std::string &value)
{
    for (KeyValueStorage::iterator i = storage.begin(); i != storage.end(); i++) {
        if (i->first == key) {
            i->second = value;
            return;
        }
    }
}

void initStorage(KeyValueStorage &storage)
{
    storage.resize(5);
    storage[0].first = ("-c");
    storage[0].second = ("16");
    storage[1].first = ("-l");
    storage[1].second = ("172.31.3.26");
    storage[2].first = ("-lp");
    storage[2].second = ("5001");
    storage[3].first = ("-d");
    storage[3].second = ("172.31.3.33");
    storage[4].first = ("-dp");
    storage[4].second = ("5002");
}

int main(int argc, char *argv[])
{
    signal(SIGINT, signal_handler);

    // Проверка на ключ help
    if (argc > 1 && (std::string(argv[1]) == "-h" || std::string(argv[1]) == "-help")) {
        std::cerr << "Usage: \n"
                     "-c codec (Default: 16)\n"
                     "-l local IP (Default: 172.31.3.26)\n"
                     "-lp local port (Default: 5001)\n"
                     "-d destination IP (Default: 172.31.3.33)\n"
                     "-dp destination port (Default: 5002)\n";
        return 0;
    }

    configure_audio_mixer();

    // Инициализация и заполнение хранилища параметров
    KeyValueStorage params;
    initStorage(params);

    for (int i = 1; i < argc - 1; i++) {
        setValue(params, argv[i], argv[i + 1]);
    }

    long codec = strtol(params[0].second.c_str(), NULL, 10);
    long local_port = strtol(params[2].second.c_str(), NULL, 10);
    long destination_port = strtol(params[4].second.c_str(), NULL, 10);

    std::string local_ip = params[1].second;
    std::string destination_ip = params[3].second;

    try {
        snd_pcm_format_t bit = snd_pcm_format_value("SND_PCM_FORMAT_S16");
        switch(codec) {
        case 8:
            bit = SND_PCM_FORMAT_S8;
            break;
        case 16:
            bit = SND_PCM_FORMAT_S16;
            break;
        case 24:
            bit = SND_PCM_FORMAT_S24;
            break;
        case 32:
            bit = SND_PCM_FORMAT_S32;
            break;
        default:
            break;
        }

        Device captureDevice("hw:1,0", SND_PCM_STREAM_CAPTURE,
            bit, 8000, 1);
        Device playbackDevice("hw:1,0", SND_PCM_STREAM_PLAYBACK,
            bit, 8000, 1);

        UdpStreamer streamer(local_ip, local_port, destination_ip,
            destination_port);
        Buffer buffer(captureDevice, playbackDevice, streamer);

        while (keep_running) {
            if (buffer.ReadFromDevice() > 0) {
                buffer.SendToUDP();
            }
            if(buffer.ReceiveFromUDP() > 0) {
                buffer.WriteToDevice();
            }
        }
    }
    catch(const std::exception &e) {
        std::cerr << "Fatal error: " << e.what() << "\n";
        return 1;
    }

    return 0;
}

